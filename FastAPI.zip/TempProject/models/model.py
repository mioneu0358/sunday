from sqlalchemy import Column, Table
from sqlalchemy.sql.sqltypes import INTEGER, FLOAT
from connect.db import meta, engine


temps = Table('temp', meta,
              Column('cnt', INTEGER(), primary_key=True, autoincrement=True),
              Column('hot', FLOAT(), nullable=False),
              Column('cold', FLOAT(), nullable=False),
              )

meta.create_all(engine)
