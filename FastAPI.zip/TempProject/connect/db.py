from sqlalchemy import create_engine, MetaData
from sqlalchemy.orm import sessionmaker


engine = create_engine('mysql+pymysql://turing:0623@turingx.kro.kr:3306/measurement')
meta = MetaData()
Session = sessionmaker(bind=engine)

